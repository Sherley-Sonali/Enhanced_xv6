#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

#define PAGE_SIZE 4096
#define NUM_PAGES 4
#define MEMORY_SIZE (PAGE_SIZE * NUM_PAGES)

void print_separator(void) {
    printf("----------------------------------------\n");
}

// Initialize memory with a pattern
void init_memory(char *mem, int size) {
    for (int i = 0; i < size; i++) {
        mem[i] = i & 0xFF;
    }
}

// Read test - should not trigger COW
int read_test(char *mem, int size) {
    int checksum = 0;
    printf("Starting read test...\n");
    
    // Read every byte
    for (int i = 0; i < size; i++) {
        checksum += mem[i];
    }
    
    printf("Read test complete. Checksum: %d\n", checksum);
    return getcowstats(); // Get current fault count
}

// Sequential write test - should trigger COW on first write to each page
int sequential_write_test(char *mem, int size) {
    printf("Starting sequential write test...\n");
    
    // Write to every byte
    for (int i = 0; i < size; i++) {
        mem[i] = 'A';
    }
    
    printf("Sequential write test complete\n");
    return getcowstats(); // Get current fault count
}

// Page-by-page write test - should trigger COW once per page
int page_write_test(char *mem, int size) {
    printf("Starting page-by-page write test...\n");
    
    // Write once to each page
    for (int i = 0; i < size; i += PAGE_SIZE) {
        mem[i] = 'B';
    }
    
    printf("Page write test complete\n");
    return getcowstats(); // Get current fault count
}

// Random access write test
int random_write_test(char *mem, int size) {
    printf("Starting random write test...\n");
    
    // Write to random locations in each page
    for (int page = 0; page < size/PAGE_SIZE; page++) {
        int offset = (uptime() % PAGE_SIZE);  // Use uptime as pseudo-random
        mem[page * PAGE_SIZE + offset] = 'C';
    }
    
    printf("Random write test complete\n");
    return getcowstats(); // Get current fault count
}

void run_test_suite(char *mem, int size, char *prefix) {
    int start_faults, end_faults;
    
    print_separator();
    printf("%s:\n", prefix);
    
    // Read test
    start_faults = getcowstats();
    read_test(mem, size);
    end_faults = getcowstats();
    printf("Read test COW faults: %d\n", end_faults - start_faults);
    
    print_separator();
    
    // Sequential write test
    start_faults = getcowstats();
    sequential_write_test(mem, size);
    end_faults = getcowstats();
    printf("Sequential write COW faults: %d\n", end_faults - start_faults);
    
    print_separator();
    
    // Page write test
    start_faults = getcowstats();
    page_write_test(mem, size);
    end_faults = getcowstats();
    printf("Page write COW faults: %d\n", end_faults - start_faults);
    
    print_separator();
    
    // Random write test
    start_faults = getcowstats();
    random_write_test(mem, size);
    end_faults = getcowstats();
    printf("Random write COW faults: %d\n", end_faults - start_faults);
    
    print_separator();
}

int main(int argc, char *argv[]) {
    printf("Starting COW Page Fault Frequency Test\n");
    printf("Memory size: %d bytes (%d pages)\n", MEMORY_SIZE, NUM_PAGES);
    print_separator();
    
    // Allocate and initialize memory
    char *mem = malloc(MEMORY_SIZE);
    if (!mem) {
        printf("Memory allocation failed!\n");
        exit(1);
    }
    
    init_memory(mem, MEMORY_SIZE);
    
    // Fork and run tests
    int pid = fork();
    if (pid < 0) {
        printf("Fork failed!\n");
        free(mem);
        exit(1);
    }
    
    if (pid == 0) {
        // Child process
        sleep(10); // Wait for parent to print its message
        run_test_suite(mem, MEMORY_SIZE, "Child Process Tests");
        exit(0);
    } else {
        // Parent process
        printf("Parent process (PID %d) created child (PID %d)\n", getpid(), pid);
        run_test_suite(mem, MEMORY_SIZE, "Parent Process Tests");
        
        // Wait for child to complete
        wait(0);
        printf("All tests completed\n");
    }
    
    free(mem);
    exit(0);
}