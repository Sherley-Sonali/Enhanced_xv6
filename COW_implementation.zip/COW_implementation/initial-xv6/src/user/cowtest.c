#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int
main(int argc, char *argv[])
{
  char *p = sbrk(4096);
  if(p == (char*)-1)
    exit(1);

  strcpy(p, "cow test");

  if(fork() == 0) {
    // Child
    if(strcmp(p, "cow test") != 0)
      exit(1);
    strcpy(p, "modified"); // Should trigger COW
    exit(0);
  } else {
    // Parent
    wait(0);
    if(strcmp(p, "cow test") != 0) // Should still see original
      exit(1);
    exit(0);
  }
}