#include "spinlock.h"
extern struct {
    struct spinlock lock;
    struct run *freelist;
} kmem;
