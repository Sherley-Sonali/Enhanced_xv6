#include "memlayout.h"

// to "COW bit" sto pte
#define COW_IMP_E (1L << 8)

typedef struct spinlock reflect_lock;